import { Component } from '@angular/core';
import { NavController, ViewController, NavParams, AlertController,  LoadingController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { IonicStorageModule } from '@ionic/Storage';
import { UserService } from "../../providers/user-service";
import { Flags } from "../../providers/flag";

@Component({
  selector: 'page-labs-edit',
  templateUrl: 'labs-edit.html'
})
export class LabsEditPage {

  save:string;
  edit:string;
  labsData:any = {};
  type:any;
  state:any;
  email:any;
  auth_token:any;
  profile_id:any;

  constructor(
    public navCtrl: NavController,
    public viewCtrl: ViewController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    public userService: UserService,
    public storage: Storage,
    private flagService: Flags
  ) {
    this.save = navParams.get("save");
    this.edit = navParams.get("edit");
    this.profile_id = navParams.get("profile_id");
    if(this.edit){
      this.labsData = {name:'Labs1', field:'filed1', procedure_date:'2015-11-22', result:'ok'};
    }
    this.type = [
      { name:'CBC',value: 0},
      { name:'BMP', value: 1},
      { name:'CMP', value: 2},
      { name:'Other', value: 3}
    ];
    this.state = [
      { name:'Private',value_string: 'true'},
      { name:'Public', value_string: 'false'} ];
  }

  deleteAlert(){

    let alert = this.alertCtrl.create({
      title: 'Are you sure?',
      subTitle: 'Do you really want to delete this item?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Ok',
          handler: () => {
            console.log('Buy clicked');
            this.deleteLabsData();
            }
          }
        ]
      });
      alert.present();
  }

  deleteLabsData(){
  }
  updateLabsData(){
  }
  createLabsData(){
    let loading = this.loadingCtrl.create();
    let endValue = "/labs";
    let body = {"lab ": this.labsData }
    console.log(body);
    loading.present();
    this.storage.get('email').then(val=>{
      this.email = val;
      this.storage.get('auth_token').then(val=>{
        this.auth_token = val;
        this.userService.dataCreate(this.email, this.auth_token, this.profile_id, endValue, body)
          .subscribe(
            (data) => {
              loading.dismiss();
              console.log("Lab Data: ", data);
              if(data.success == false){
                let alert = this.alertCtrl.create({
                  title: "Error", subTitle: "Create Error", buttons: ['OK']
                });
                alert.present();
              } else{
                this.flagService.setChangedFlag(true);
                let alert = this.alertCtrl.create({
                  title: "Created", subTitle: "Create Success", buttons: ['OK']
                });
                alert.present();
                this.navCtrl.pop();
                console.log(data);
              }
          });
      });
    });
  }
  dismiss() {
   this.viewCtrl.dismiss();
  }

}
