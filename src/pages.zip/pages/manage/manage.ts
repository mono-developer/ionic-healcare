import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-manage',
  templateUrl: 'manage.html'
})
export class ManagePage {

  constructor(public navCtrl: NavController) {

  }
  closePage(){
    this.navCtrl.pop();
  }
}
