import { Component } from '@angular/core';
import { NavController, ViewController, NavParams, AlertController,  LoadingController  } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { IonicStorageModule } from '@ionic/Storage';
import { UserService } from "../../providers/user-service";
import { Flags } from "../../providers/flag";

@Component({
  selector: 'page-family-history-edit',
  templateUrl: 'family-history-edit.html'
})
export class FamilyHistoryEditPage {

  save:string;
  edit:string;
  familyHistoryData:any = {};
  deceased:any;
  relationship:any;
  state:any;
  profile_id:any;
  email:string;
  auth_token:string;

  constructor(
    public navCtrl: NavController,
    public viewCtrl: ViewController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public loadingCtrl: LoadingController,
    public userService: UserService,
    public storage: Storage,
    private flagService: Flags
  ) {

    this.save = navParams.get("save");
    this.edit = navParams.get("edit");
    this.profile_id = navParams.get("profile_id");
    if(this.edit){
      this.familyHistoryData = { name: 'Family History1', relationship: 3, birth_date:'1965-01-05',
                            state:'Living', death_date:'', condition:'Good', notes:'Ok'};
    }
    this.deceased = [
      { name:'Deceased',value_string: "true"},
      { name:'Living', value_string: "false"} ];
    this.relationship = [
      { name:'Brother', value: 0},
      { name:'Sister', value: 1},
      { name:'Mother', value: 2 },
      { name:'Father', value: 3},
      { name:'Aunt', value: 4},
      { name:'Uncle', value: 5},
      { name:'Grandfather', value:6 },
      { name:'Grandmother', value: 7},
      { name:'Other', value: 8}
    ]
    this.state = [
      { name:'Private',value_string: 'true'},
      { name:'Public', value_string: 'false'} ];
  }

  deleteAlert(){

    let alert = this.alertCtrl.create({
      title: 'Are you sure?',
      subTitle: 'Do you really want to delete this item?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Ok',
          handler: () => {
            console.log('Buy clicked');
            this.deleteFamilyHistoryData();
            }
          }
        ]
      });
      alert.present();
  }

  deleteFamilyHistoryData(){
    console.log(this.familyHistoryData.relationship);
  }
  updateFamilyHistoryData(){
  }
  createFamilyHistoryData(){
    let loading = this.loadingCtrl.create();
    var endValue = "/family_histories";

    var body = {"family_history": this.familyHistoryData }
    console.log(body);
    loading.present();
    this.storage.get('email').then(val=>{
      this.email = val;
      this.storage.get('auth_token').then(val=>{
        this.auth_token = val;
        this.userService.dataCreate(this.email, this.auth_token, this.profile_id, endValue, body)
          .subscribe(
            (data) => {
              loading.dismiss();
              console.log("familyHistoryData Data: ", data);
              if(data.success == false){
                let alert = this.alertCtrl.create({
                  title: "Error", subTitle: "Create Error", buttons: ['OK']
                });
                alert.present();
                this.navCtrl.pop();
              } else{
                this.flagService.setChangedFlag(true);
                let alert = this.alertCtrl.create({
                  title: "Created", subTitle: "Created Success", buttons: ['OK']
                });
                alert.present();
                this.navCtrl.pop();
                console.log(data);
              }
          });
      });
    });
  }
  dismiss() {
   this.viewCtrl.dismiss();
  }

}
