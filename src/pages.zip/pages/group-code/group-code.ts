import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-group-code',
  templateUrl: 'group-code.html'
})
export class GroupCodePage {

  constructor(public navCtrl: NavController) {

  }

}
