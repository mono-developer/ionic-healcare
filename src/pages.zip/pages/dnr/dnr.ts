import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-dnr',
  templateUrl: 'dnr.html'
})
export class DNRPage {

  constructor(public navCtrl: NavController) {

  }
  closePage(){
    this.navCtrl.pop();
  }
}
